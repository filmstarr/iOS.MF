<?php

/*
* Templates for various menus throughout the theme. We're not going to use these though.
*
* License: http://www.opensource.org/licenses/mit-license.php
*/


function template_generic_menu_sidebar_above() {
}

function template_generic_menu_sidebar_below() {
}

function template_generic_menu_dropdown_above() {
}

function template_generic_menu_dropdown_below() {
}

function template_generic_menu_tabs(&$menu_context) {
}

?>