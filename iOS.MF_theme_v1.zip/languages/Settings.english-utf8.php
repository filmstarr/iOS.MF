<?php
// Version: 2.0 RC4; Settings

global $settings;

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = 'An iOS optimised theme for iPhone, iPad and iPod Touch<br /><br />Author: <a href="mailto:filmstarr@hotmail.com.com">filmstarr</a><br /><br />Based on: <a url="http://custom.simplemachines.org/themes/index.php?lemma=2089">SMF4iPhone</a> by Fabius, butchs and FarFromPerfection.';

?>