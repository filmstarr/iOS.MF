/*
* Sources:
* https://dribbble.com/shots/1372400-Infinite-Loop-Gif?list=buckets&offset=7
*/

ajax-loader.gif generated from Infinite Loop (Gif) by Rob Nichols
thumbnail.png and noavatar.png created by the author (Ross Huelin)