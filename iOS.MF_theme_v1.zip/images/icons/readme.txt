/*
* Sources:
* http://graphicburger.com/simple-line-icons-set-vol-1/
* http://graphicburger.com/simple-line-icons-set-vol-2/
* http://graphicburger.com/simple-line-icons-set-vol-3/
* http://graphicburger.com/simple-line-icons-set-vol-4/
*/

Licence: http://graphicburger.com/license/

All icons generated from the Graphic Burger Simple Line Icon set.