<?php

/*
* Uninstall iOS.MF modification
*
* License: http://www.opensource.org/licenses/mit-license.php
*/


remove_integration_function('integrate_theme_include', '$sourcedir/iOS.MF.ThemeFunctions.php');

?>